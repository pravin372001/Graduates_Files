package com.zsgs.librarymanagement.login;

import java.util.Scanner;

import com.zsgs.librarymanagement.LibraryManagement;
import com.zsgs.librarymanagement.admin.AdminView;

public class LoginView {
    LoginModel loginModel;

    Scanner scanner = new Scanner(System.in);

    public LoginView() {
        loginModel = new LoginModel(this);
    }

    public void init() {
        System.out.println("Login Page");
        System.out.print("Enter the user name: ");
        String userName = scanner.next();
        System.out.print("Enter the password: ");
        String password = scanner.next();
        loginModel.validateUser(userName, password);
    }

    public void onSuccess() {
        System.out.flush();
        System.out.println("\n\nLogin successful...\n\n ---- welcome to " + LibraryManagement.getInstance().getAppName()
                + " - v" + LibraryManagement.getInstance().getAppVersion() + "----");
        AdminView adminView = new AdminView();
        adminView.initiateSetup();
    }

    public void showMessage(String message) {
        System.out.println(message);
    }
}
