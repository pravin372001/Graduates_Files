package com.zsgs.librarymanagement.librarysetup;

import com.zsgs.librarymanagement.homepage.HomePage;
import com.zsgs.librarymanagement.model.Library;

import java.util.Scanner;

public class LibrarySetUpView {
  private LibrarySetUpModel librarySetUpModel;

  Scanner scanner = new Scanner(System.in);

  public LibrarySetUpView() {
    librarySetUpModel = new LibrarySetUpModel(this);
  }

  public void init() {
    librarySetUpModel.startSetup();
  }

  public void onSetupComplete() {
    System.out.println("\nLibrary setup completed");
    HomePage.getInstance().init();
  }

  public void showAlert(String alert) {
    System.out.println("\n");
  }

  public void initiateSetup() {
    System.out.println("\n\nEnter the Library Details \n\n");
    System.out.println("\nEnter Library Name: ");
    String libraryName = scanner.next();
    System.out.println("Enter Library Id: ");
    int libraryId = scanner.nextInt();
    System.out.println("Enter Phone Number: ");
    String phoneNo = scanner.next();
    System.out.println("Enter Email Id: ");
    String emailId = scanner.next();
    System.out.println("Enter Address: ");
    scanner.nextLine();
    String address = scanner.nextLine();
    Library library = new Library(libraryName, libraryId, phoneNo, emailId, address);
    librarySetUpModel.saveLibraryDetails(library);
    onSetupComplete();
  }
}
