package com.zsgs.librarymanagement.admin;

import java.util.Scanner;

import com.zsgs.librarymanagement.homepage.HomePage;
import com.zsgs.librarymanagement.librarysetup.LibrarySetUpView;

public class AdminView {
    Scanner scanner = new Scanner(System.in);
    AdminModel adminModel;

    public AdminView() {
        adminModel = new AdminModel(this);
    }

    public void initiateSetup() {
        if (adminModel.isDefaultPassword()) {
            System.out.println("Initiate Setup");
            System.out.print("Enter the new password : ");
            String password = scanner.next();
            System.out.print("Enter the email id : ");
            String emailId = scanner.next();
            System.out.print("Enter the phone number : ");
            String phoneNumber = scanner.next();
            adminModel.initiateSetup(password, emailId, phoneNumber);
        } else {
            HomePage.getInstance().init();
        }
    }

    public void onSetupComplete() {
        System.out.println("Setup completed successfully...");
        LibrarySetUpView librarySetupView = new LibrarySetUpView();
        librarySetupView.init();

    }
}
